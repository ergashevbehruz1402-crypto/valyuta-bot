# 💱 Valyuta Bot

Telegram uchun valyuta kurslarini ko'rsatadigan va konvertatsiya qiladigan bot.
`aiogram 3.x` va `aiohttp` orqali ExchangeRate-API bilan integratsiya qilingan.

## 📁 Fayl tuzilmasi

```
valyuta_bot/
├── main.py           — Handler'lar, API so'rovlar, kurslar keshi, dispatcher
├── buttons.py         — ReplyKeyboard va InlineKeyboard tugmalari
├── database.py         — SQLite orqali foydalanuvchilar, sevimli valyutalar
├── config.py           — BOT_TOKEN, ADMIN_ID, EXCHANGE_API_KEY
├── requirements.txt
└── locales/
    ├── uz.json
    ├── ru.json
    └── en.json
```

## ⚙️ O'rnatish

1. Kerakli kutubxonalarni o'rnating:

```bash
pip install -r requirements.txt
```

2. Muhit o'zgaruvchilarini o'rnating (yoki `config.py` ni to'g'ridan-to'g'ri tahrirlang):

```bash
export BOT_TOKEN="123456:ABC-YourBotTokenHere"
export ADMIN_ID="123456789"
export ADMIN_USERNAME="your_admin_username"
export EXCHANGE_API_KEY=""   # ixtiyoriy, bo'sh qoldirilsa ochiq API ishlatiladi
```

- `BOT_TOKEN` — @BotFather dan olinadi.
- `ADMIN_ID` — sizning Telegram ID raqamingiz.
- `ADMIN_USERNAME` — `/help` komandasida ko'rsatiladigan username.
- `EXCHANGE_API_KEY` — [exchangerate-api.com](https://www.exchangerate-api.com/) dan olingan kalit
  (ixtiyoriy — bo'sh bo'lsa, bot avtomatik ravishda `open.er-api.com` ochiq endpointidan foydalanadi).

## ▶️ Ishga tushirish

```bash
python main.py
```

Bot ishga tushgach:
- `valyuta.db` ma'lumotlar bazasi avtomatik yaratiladi;
- kurslar birinchi marta darhol yuklanadi;
- shundan so'ng har **1 soatda** (`CACHE_TTL_SECONDS`, standart 3600 soniya) fon vazifasi orqali
  avtomatik yangilanib turadi, shu bilan birga har bir so'rovda ham kesh eskirgan bo'lsa yangilanadi.

## ✨ Funksiyalar

**Foydalanuvchi uchun:**
- **Kurs ko'rish** — asosiy valyutalar (USD, EUR, RUB, GBP) kursini chiqaradi; agar sevimli
  valyutalar tanlangan bo'lsa, faqat o'shalar ko'rsatiladi.
- **Valyuta almashtirish** — summa → manba valyuta → maqsad valyuta ketma-ketligida so'raydi
  va natijani `100 USD = 12 700 000 UZS` ko'rinishida chiqaradi.
- **Sevimli valyuta** — kuzatmoqchi bo'lgan valyutalarni belgilash (✅/⬜️ inline tugmalar orqali).
- `/language` — bot interfeysi tilini (O'zbek / Русский / English) tanlash.

**Admin uchun (faqat `ADMIN_ID` ga mos foydalanuvchiga ko'rinadi):**
- **Statistika** — jami foydalanuvchilar soni va top-5 eng ko'p so'ralgan valyuta juftligi.
- **Reklama yuborish** — barcha foydalanuvchilarga xabar yuborish (tasdiqlash/bekor qilish bilan).

## 📌 Komandalar

| Komanda | Tavsif |
|---|---|
| `/start` | Botni ishga tushiradi |
| `/kurs` | Joriy kurslarni ko'rsatadi |
| `/almashtir` | Valyuta almashtirish jarayonini boshlaydi |
| `/sevimli` | Sevimli valyutalarni boshqarish |
| `/language` | Bot interfeysi tilini tanlaydi |
| `/help` | Admin bilan bog'lanish havolasini ko'rsatadi |

## ⚠️ Eslatma

- Agar `EXCHANGE_API_KEY` berilmasa, bot avtomatik ravishda `https://open.er-api.com` (kalitsiz,
  bepul) endpointidan foydalanadi. Ishlab chiqarish muhitida barqarorlik uchun ro'yxatdan o'tib,
  shaxsiy API kalit olish tavsiya etiladi.
- Kurslar xotirada (in-memory) keshlanadi va har 1 soatda avtomatik yangilanadi; shu bilan birga
  har safar so'rov kelganda kesh eskirgan bo'lsa (1 soatdan oshgan bo'lsa) ham yangilanadi.
- API bilan bog'lanishda xatolik yuz bersa, foydalanuvchiga tushunarli xabar ko'rsatiladi va
  bot ishlashda davom etadi (eski kesh mavjud bo'lsa, undan foydalaniladi).
- Ishlab chiqarish (production) muhitida `BOT_TOKEN` kabi maxfiy ma'lumotlarni kodga yozmasdan,
  muhit o'zgaruvchilari yoki `.env` fayl orqali berish tavsiya etiladi.
