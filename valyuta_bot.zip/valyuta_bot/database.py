# database.py
# Foydalanuvchilar, sevimli valyutalar va so'rovlar statistikasini SQLite orqali saqlash.

import sqlite3
from contextlib import closing

import config

DB_PATH = config.DB_PATH


def init_db() -> None:
    """Baza va jadvallarni yaratadi (agar mavjud bo'lmasa)."""
    with closing(sqlite3.connect(DB_PATH)) as conn:
        cur = conn.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                interface_lang TEXT DEFAULT 'uz',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS favorites (
                user_id INTEGER,
                currency TEXT,
                PRIMARY KEY (user_id, currency)
            )
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS conversions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                from_currency TEXT,
                to_currency TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.commit()


def add_user(user_id: int, username: str) -> None:
    with closing(sqlite3.connect(DB_PATH)) as conn:
        cur = conn.cursor()
        cur.execute("SELECT user_id FROM users WHERE user_id = ?", (user_id,))
        if cur.fetchone() is None:
            cur.execute(
                "INSERT INTO users (user_id, username) VALUES (?, ?)",
                (user_id, username or ""),
            )
        else:
            cur.execute(
                "UPDATE users SET username = ? WHERE user_id = ?",
                (username or "", user_id),
            )
        conn.commit()


def get_user(user_id: int):
    with closing(sqlite3.connect(DB_PATH)) as conn:
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        return cur.fetchone()


def set_interface_lang(user_id: int, lang: str) -> None:
    with closing(sqlite3.connect(DB_PATH)) as conn:
        cur = conn.cursor()
        cur.execute(
            "UPDATE users SET interface_lang = ? WHERE user_id = ?", (lang, user_id)
        )
        conn.commit()


def add_favorite(user_id: int, currency: str) -> None:
    with closing(sqlite3.connect(DB_PATH)) as conn:
        cur = conn.cursor()
        cur.execute(
            "INSERT OR IGNORE INTO favorites (user_id, currency) VALUES (?, ?)",
            (user_id, currency),
        )
        conn.commit()


def remove_favorite(user_id: int, currency: str) -> None:
    with closing(sqlite3.connect(DB_PATH)) as conn:
        cur = conn.cursor()
        cur.execute(
            "DELETE FROM favorites WHERE user_id = ? AND currency = ?",
            (user_id, currency),
        )
        conn.commit()


def get_favorites(user_id: int):
    with closing(sqlite3.connect(DB_PATH)) as conn:
        cur = conn.cursor()
        cur.execute(
            "SELECT currency FROM favorites WHERE user_id = ? ORDER BY currency",
            (user_id,),
        )
        return [row[0] for row in cur.fetchall()]


def toggle_favorite(user_id: int, currency: str) -> bool:
    """Agar valyuta sevimlilarda bo'lsa o'chiradi, bo'lmasa qo'shadi. True = qo'shildi."""
    favorites = get_favorites(user_id)
    if currency in favorites:
        remove_favorite(user_id, currency)
        return False
    add_favorite(user_id, currency)
    return True


def log_conversion(user_id: int, from_currency: str, to_currency: str) -> None:
    with closing(sqlite3.connect(DB_PATH)) as conn:
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO conversions (user_id, from_currency, to_currency) VALUES (?, ?, ?)",
            (user_id, from_currency, to_currency),
        )
        conn.commit()


def get_total_users() -> int:
    with closing(sqlite3.connect(DB_PATH)) as conn:
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM users")
        return cur.fetchone()[0]


def get_top_currency_pairs(limit: int = 5):
    """Eng ko'p so'ralgan valyuta juftliklari: [(from, to, count), ...]"""
    with closing(sqlite3.connect(DB_PATH)) as conn:
        cur = conn.cursor()
        cur.execute(
            """
            SELECT from_currency, to_currency, COUNT(*) as cnt
            FROM conversions
            GROUP BY from_currency, to_currency
            ORDER BY cnt DESC
            LIMIT ?
            """,
            (limit,),
        )
        return cur.fetchall()


def get_all_user_ids():
    with closing(sqlite3.connect(DB_PATH)) as conn:
        cur = conn.cursor()
        cur.execute("SELECT user_id FROM users")
        return [row[0] for row in cur.fetchall()]
