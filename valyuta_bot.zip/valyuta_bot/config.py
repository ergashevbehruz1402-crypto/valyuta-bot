# config.py
# Botning asosiy sozlamalari. Haqiqiy loyihada bu qiymatlarni muhit
# o'zgaruvchilari (environment variables) yoki .env fayl orqali berish tavsiya etiladi.

import os

# Telegram bot tokeni (@BotFather dan olinadi)
BOT_TOKEN = os.getenv("BOT_TOKEN", "PUT_YOUR_BOT_TOKEN_HERE")

# Admin foydalanuvchining Telegram ID raqami
ADMIN_ID = int(os.getenv("ADMIN_ID", "123456789"))

# /help komandasi uchun admin username (@ belgisisiz)
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin_username")

# ExchangeRate-API (https://www.exchangerate-api.com/) API kaliti.
# Bepul "open" endpoint ham mavjud (kalitsiz), lekin barqarorlik uchun kalit tavsiya etiladi.
EXCHANGE_API_KEY = os.getenv("EXCHANGE_API_KEY", "")

# Agar API_KEY berilgan bo'lsa, pullik/ro'yxatdan o'tgan endpoint ishlatiladi:
#   https://v6.exchangerate-api.com/v6/<API_KEY>/latest/USD
# Aks holda ochiq (kalitsiz) endpoint ishlatiladi:
#   https://open.er-api.com/v6/latest/USD
EXCHANGE_API_URL_WITH_KEY = "https://v6.exchangerate-api.com/v6/{api_key}/latest/{base}"
EXCHANGE_API_URL_OPEN = "https://open.er-api.com/v6/latest/{base}"

# Kurslar qaysi bazaviy valyutada olinadi (barcha kurslar shundan hisoblanadi)
BASE_CURRENCY = "USD"

# Kurslarni necha soniyada bir marta yangilash kerak (1 soat = 3600 soniya)
CACHE_TTL_SECONDS = int(os.getenv("CACHE_TTL_SECONDS", "3600"))

# Ma'lumotlar bazasi fayli
DB_PATH = os.getenv("DB_PATH", "valyuta.db")
