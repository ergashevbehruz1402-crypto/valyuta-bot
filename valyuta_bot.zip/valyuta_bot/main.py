# main.py
# Valyuta Bot — asosiy fayl: handlerlar, ExchangeRate-API bilan integratsiya, dispatcher.

import asyncio
import json
import logging
import os
import time
from datetime import datetime

import aiohttp
from aiogram import Bot, Dispatcher, Router, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import CallbackQuery, Message

import buttons
import config
import database as db

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOCALES_DIR = os.path.join(BASE_DIR, "locales")
DEFAULT_LOCALE = "uz"

_locales_cache: dict[str, dict] = {}

router = Router()


# ---------------------------------------------------------------------------
# Lokalizatsiya yordamchi funksiyalari
# ---------------------------------------------------------------------------
def load_locale(lang: str) -> dict:
    if lang not in _locales_cache:
        path = os.path.join(LOCALES_DIR, f"{lang}.json")
        if not os.path.exists(path):
            path = os.path.join(LOCALES_DIR, f"{DEFAULT_LOCALE}.json")
        with open(path, "r", encoding="utf-8") as f:
            _locales_cache[lang] = json.load(f)
    return _locales_cache[lang]


def get_locale_for(user_id: int) -> dict:
    user = db.get_user(user_id)
    lang = user["interface_lang"] if user else DEFAULT_LOCALE
    return load_locale(lang or DEFAULT_LOCALE)


def is_admin(user_id: int) -> bool:
    return user_id == config.ADMIN_ID


# ---------------------------------------------------------------------------
# FSM holatlari
# ---------------------------------------------------------------------------
class ConvertCurrency(StatesGroup):
    waiting_amount = State()
    waiting_from = State()
    waiting_to = State()


class Broadcast(StatesGroup):
    waiting_message = State()


# ---------------------------------------------------------------------------
# Kurslar keshi — har 1 soatda (config.CACHE_TTL_SECONDS) yangilanadi
# ---------------------------------------------------------------------------
class RatesCache:
    def __init__(self) -> None:
        self.rates: dict[str, float] = {}
        self.base: str = config.BASE_CURRENCY
        self.last_updated: float = 0.0
        self._lock = asyncio.Lock()

    def is_fresh(self) -> bool:
        return bool(self.rates) and (time.time() - self.last_updated) < config.CACHE_TTL_SECONDS

    async def get_rates(self) -> dict:
        """Kurslarni qaytaradi; agar kesh eskirgan bo'lsa, avval yangilaydi."""
        async with self._lock:
            if not self.is_fresh():
                await self._refresh()
            return self.rates

    async def _refresh(self) -> None:
        if config.EXCHANGE_API_KEY:
            url = config.EXCHANGE_API_URL_WITH_KEY.format(
                api_key=config.EXCHANGE_API_KEY, base=self.base
            )
        else:
            url = config.EXCHANGE_API_URL_OPEN.format(base=self.base)

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                    data = await resp.json()

            # v6.exchangerate-api.com va open.er-api.com javob formatlari mos keladi:
            # {"result": "success", "conversion_rates": {...}} yoki {"rates": {...}}
            rates = data.get("conversion_rates") or data.get("rates")
            if not rates:
                raise ValueError(f"API javobida kurslar topilmadi: {data}")

            self.rates = rates
            self.last_updated = time.time()
            logger.info("Valyuta kurslari yangilandi (%d ta valyuta).", len(rates))
        except Exception as e:  # noqa: BLE001
            logger.error("Kurslarni yangilashda xatolik: %s", e)
            if not self.rates:
                # Kesh bo'sh bo'lsa, xatolikni yuqoriga uzatamiz
                raise


rates_cache = RatesCache()


async def convert_amount(amount: float, from_cur: str, to_cur: str) -> float:
    """amount ni from_cur dan to_cur ga aylantiradi (baza: config.BASE_CURRENCY)."""
    rates = await rates_cache.get_rates()
    if from_cur == rates_cache.base:
        rate_from = 1.0
    else:
        rate_from = rates.get(from_cur)
    if to_cur == rates_cache.base:
        rate_to = 1.0
    else:
        rate_to = rates.get(to_cur)

    if rate_from is None or rate_to is None:
        raise ValueError(f"Valyuta kursi topilmadi: {from_cur} yoki {to_cur}")

    # Avval baza valyutaga o'tkazamiz, keyin maqsad valyutaga
    amount_in_base = amount / rate_from
    result = amount_in_base * rate_to
    return result


def format_number(value: float) -> str:
    """Sonni chiroyli formatda ko'rsatadi: 12700000 -> 12 700 000, 99.5 -> 99.5"""
    if value == int(value):
        formatted = f"{int(value):,}".replace(",", " ")
    else:
        formatted = f"{value:,.2f}".replace(",", " ")
    return formatted


# ---------------------------------------------------------------------------
# /start
# ---------------------------------------------------------------------------
@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext) -> None:
    await state.clear()
    db.add_user(message.from_user.id, message.from_user.username or "")
    locale = get_locale_for(message.from_user.id)
    await message.answer(
        locale["start_welcome"],
        reply_markup=buttons.main_menu_keyboard(locale, is_admin(message.from_user.id)),
    )


# ---------------------------------------------------------------------------
# /help
# ---------------------------------------------------------------------------
@router.message(Command("help"))
async def cmd_help(message: Message) -> None:
    locale = get_locale_for(message.from_user.id)
    await message.answer(locale["help_text"].format(admin=config.ADMIN_USERNAME))


# ---------------------------------------------------------------------------
# /language
# ---------------------------------------------------------------------------
@router.message(Command("language"))
async def cmd_language(message: Message) -> None:
    locale = get_locale_for(message.from_user.id)
    await message.answer(
        locale["language_select_prompt"], reply_markup=buttons.interface_language_keyboard()
    )


@router.callback_query(F.data.startswith("setlang:"))
async def cb_set_language(callback: CallbackQuery, state: FSMContext) -> None:
    lang = callback.data.split(":", 1)[1]
    db.add_user(callback.from_user.id, callback.from_user.username or "")
    db.set_interface_lang(callback.from_user.id, lang)
    locale = load_locale(lang)
    await callback.message.edit_text(locale["language_changed"])
    await callback.message.answer(
        locale["start_welcome"],
        reply_markup=buttons.main_menu_keyboard(locale, is_admin(callback.from_user.id)),
    )
    await callback.answer()


# ---------------------------------------------------------------------------
# Kurs ko'rish: /kurs komandasi va "Kurs ko'rish" tugmasi
# ---------------------------------------------------------------------------
async def _show_rates(message: Message) -> None:
    locale = get_locale_for(message.from_user.id)
    try:
        rates = await rates_cache.get_rates()
    except Exception:  # noqa: BLE001
        await message.answer(locale["rates_error"])
        return

    favorites = db.get_favorites(message.from_user.id)
    display_list = favorites if favorites else buttons.DEFAULT_DISPLAY_CURRENCIES

    lines = []
    for code in display_list:
        if code == rates_cache.base:
            continue
        rate = rates.get(code)
        if rate is None:
            continue
        # 1 BASE = rate CODE, foydalanuvchiga esa 1 CODE = ? BASE qulayroq (masalan 1 USD = 12700000 UZS)
        # Buning uchun teskari kursni ko'rsatamiz: base valyutasida 1 birlik necha CODE bo'ladi.
        label = buttons.CURRENCIES.get(code, code)
        lines.append(f"{label}: {format_number(rate)}")

    rates_text = "\n".join(lines) if lines else locale["no_data"]
    updated_str = datetime.fromtimestamp(rates_cache.last_updated).strftime("%Y-%m-%d %H:%M")
    text = locale["rates_title"].format(base=rates_cache.base, rates=rates_text)
    text += locale["rates_updated_at"].format(time=updated_str)
    await message.answer(text)


@router.message(Command("kurs"))
async def cmd_kurs(message: Message) -> None:
    await _show_rates(message)


@router.message(F.text.in_(["Kurs ko'rish", "Курс валют", "View rates"]))
async def btn_view_rates(message: Message) -> None:
    await _show_rates(message)


# ---------------------------------------------------------------------------
# Valyuta almashtirish: /almashtir komandasi va "Valyuta almashtirish" tugmasi
# ---------------------------------------------------------------------------
async def _start_convert(message: Message, state: FSMContext) -> None:
    locale = get_locale_for(message.from_user.id)
    await state.set_state(ConvertCurrency.waiting_amount)
    await message.answer(locale["enter_amount"])


@router.message(Command("almashtir"))
async def cmd_almashtir(message: Message, state: FSMContext) -> None:
    await _start_convert(message, state)


@router.message(F.text.in_(["Valyuta almashtirish", "Обмен валют", "Convert currency"]))
async def btn_convert(message: Message, state: FSMContext) -> None:
    await _start_convert(message, state)


@router.message(ConvertCurrency.waiting_amount)
async def receive_amount(message: Message, state: FSMContext) -> None:
    locale = get_locale_for(message.from_user.id)
    text = (message.text or "").strip().replace(",", ".")
    try:
        amount = float(text)
        if amount <= 0:
            raise ValueError("Summa musbat bo'lishi kerak")
    except ValueError:
        await message.answer(locale["invalid_amount"])
        return

    await state.update_data(amount=amount)
    await state.set_state(ConvertCurrency.waiting_from)
    await message.answer(
        locale["choose_from_currency"], reply_markup=buttons.currency_inline_keyboard("cvfrom")
    )


@router.callback_query(ConvertCurrency.waiting_from, F.data.startswith("cvfrom:"))
async def cb_convert_from(callback: CallbackQuery, state: FSMContext) -> None:
    from_cur = callback.data.split(":", 1)[1]
    await state.update_data(from_cur=from_cur)
    await state.set_state(ConvertCurrency.waiting_to)
    locale = get_locale_for(callback.from_user.id)
    await callback.message.edit_text(locale["choose_to_currency"])
    await callback.message.answer(
        locale["choose_to_currency"], reply_markup=buttons.currency_inline_keyboard("cvto")
    )
    await callback.answer()


@router.callback_query(ConvertCurrency.waiting_to, F.data.startswith("cvto:"))
async def cb_convert_to(callback: CallbackQuery, state: FSMContext) -> None:
    to_cur = callback.data.split(":", 1)[1]
    data = await state.get_data()
    amount = data.get("amount")
    from_cur = data.get("from_cur")
    locale = get_locale_for(callback.from_user.id)

    try:
        result = await convert_amount(amount, from_cur, to_cur)
        db.log_conversion(callback.from_user.id, from_cur, to_cur)
        text = locale["convert_result"].format(
            amount=format_number(amount),
            from_cur=from_cur,
            result=format_number(result),
            to_cur=to_cur,
        )
        await callback.message.edit_text(text)
    except Exception:  # noqa: BLE001
        await callback.message.edit_text(locale["convert_error"])

    await state.clear()
    await callback.answer()


# ---------------------------------------------------------------------------
# Sevimli valyuta: /sevimli komandasi va "Sevimli valyuta" tugmasi
# ---------------------------------------------------------------------------
async def _show_favorites_menu(message: Message) -> None:
    locale = get_locale_for(message.from_user.id)
    favorites = db.get_favorites(message.from_user.id)
    await message.answer(
        locale["favorites_prompt"],
        reply_markup=buttons.favorites_inline_keyboard(favorites),
    )


@router.message(Command("sevimli"))
async def cmd_sevimli(message: Message) -> None:
    await _show_favorites_menu(message)


@router.message(F.text.in_(["Sevimli valyuta", "Избранная валюта", "Favorite currency"]))
async def btn_favorites(message: Message) -> None:
    await _show_favorites_menu(message)


@router.callback_query(F.data.startswith("fav:"))
async def cb_toggle_favorite(callback: CallbackQuery) -> None:
    value = callback.data.split(":", 1)[1]
    locale = get_locale_for(callback.from_user.id)

    if value == "done":
        favorites = db.get_favorites(callback.from_user.id)
        favorites_text = ", ".join(favorites) if favorites else locale["favorites_empty"]
        await callback.message.edit_text(locale["favorites_saved"].format(favorites=favorites_text))
        await callback.answer()
        return

    db.toggle_favorite(callback.from_user.id, value)
    favorites = db.get_favorites(callback.from_user.id)
    await callback.message.edit_reply_markup(
        reply_markup=buttons.favorites_inline_keyboard(favorites)
    )
    await callback.answer()


# ---------------------------------------------------------------------------
# ADMIN: Statistika
# ---------------------------------------------------------------------------
@router.message(F.text.in_(["Statistika", "Статистика", "Statistics"]))
async def btn_stats(message: Message) -> None:
    if not is_admin(message.from_user.id):
        return

    locale = get_locale_for(message.from_user.id)
    total = db.get_total_users()
    top_pairs = db.get_top_currency_pairs(5)

    if top_pairs:
        pairs_text = "\n".join(
            f"{i + 1}. {p[0]} → {p[1]} ({p[2]} ta)" for i, p in enumerate(top_pairs)
        )
    else:
        pairs_text = locale["no_data"]

    await message.answer(locale["stats_text"].format(total=total, pairs=pairs_text))


# ---------------------------------------------------------------------------
# ADMIN: Reklama yuborish (Broadcast)
# ---------------------------------------------------------------------------
@router.message(F.text.in_(["Reklama yuborish", "Рассылка", "Broadcast"]))
async def btn_broadcast(message: Message, state: FSMContext) -> None:
    if not is_admin(message.from_user.id):
        return

    locale = get_locale_for(message.from_user.id)
    await state.set_state(Broadcast.waiting_message)
    await message.answer(locale["broadcast_prompt"])


@router.message(Broadcast.waiting_message)
async def receive_broadcast_message(message: Message, state: FSMContext) -> None:
    if not is_admin(message.from_user.id):
        await state.clear()
        return

    locale = get_locale_for(message.from_user.id)
    await state.update_data(broadcast_text=message.text)
    await message.answer(
        locale["broadcast_confirm"].format(text=message.text),
        reply_markup=buttons.confirm_keyboard(locale),
    )


@router.callback_query(F.data == "broadcast_confirm")
async def cb_broadcast_confirm(callback: CallbackQuery, state: FSMContext) -> None:
    if not is_admin(callback.from_user.id):
        await callback.answer()
        return

    data = await state.get_data()
    text = data.get("broadcast_text")
    locale = get_locale_for(callback.from_user.id)

    if not text:
        await callback.answer()
        return

    bot = callback.bot
    user_ids = db.get_all_user_ids()
    sent, failed = 0, 0

    for uid in user_ids:
        try:
            await bot.send_message(uid, text)
            sent += 1
        except Exception as e:  # noqa: BLE001
            logger.warning("Reklamani %s ga yuborib bo'lmadi: %s", uid, e)
            failed += 1
        await asyncio.sleep(0.05)  # Telegram rate-limit uchun kichik pauza

    await callback.message.edit_text(locale["broadcast_sent"].format(sent=sent, failed=failed))
    await state.clear()
    await callback.answer()


@router.callback_query(F.data == "broadcast_cancel")
async def cb_broadcast_cancel(callback: CallbackQuery, state: FSMContext) -> None:
    locale = get_locale_for(callback.from_user.id)
    await callback.message.edit_text(locale["broadcast_cancelled"])
    await state.clear()
    await callback.answer()


# ---------------------------------------------------------------------------
# Qolgan barcha matnlar uchun standart javob (menyuni ko'rsatadi).
# Bu handler ENG OXIRIDA ro'yxatdan o'tkazilishi shart.
# ---------------------------------------------------------------------------
@router.message(F.text)
async def catch_all_text(message: Message, state: FSMContext) -> None:
    current_state = await state.get_state()
    if current_state is not None:
        return

    db.add_user(message.from_user.id, message.from_user.username or "")
    locale = get_locale_for(message.from_user.id)
    await message.answer(
        locale["unknown_command"],
        reply_markup=buttons.main_menu_keyboard(locale, is_admin(message.from_user.id)),
    )


# ---------------------------------------------------------------------------
# Fon vazifasi: kurslarni har CACHE_TTL_SECONDS da avtomatik yangilab turadi
# ---------------------------------------------------------------------------
async def periodic_rates_refresh() -> None:
    while True:
        try:
            await rates_cache.get_rates()
        except Exception as e:  # noqa: BLE001
            logger.error("Fon vazifasida kurslarni yangilashda xatolik: %s", e)
        await asyncio.sleep(config.CACHE_TTL_SECONDS)


# ---------------------------------------------------------------------------
# Botni ishga tushirish
# ---------------------------------------------------------------------------
async def main() -> None:
    db.init_db()

    bot = Bot(
        token=config.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher(storage=MemoryStorage())
    dp.include_router(router)

    await bot.delete_webhook(drop_pending_updates=True)

    # Kurslarni birinchi marta oldindan yuklab olishga urinib ko'ramiz (xato bo'lsa botni to'xtatmaydi)
    try:
        await rates_cache.get_rates()
    except Exception as e:  # noqa: BLE001
        logger.warning("Boshlang'ich kurslarni yuklab bo'lmadi: %s", e)

    asyncio.create_task(periodic_rates_refresh())

    logger.info("Valyuta bot ishga tushdi...")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
