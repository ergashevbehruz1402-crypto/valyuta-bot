# buttons.py
# ReplyKeyboard va InlineKeyboard tugmalari shu yerda tuziladi.

from aiogram.types import (
    ReplyKeyboardMarkup,
    KeyboardButton,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
)

# Botda qo'llab-quvvatlanadigan asosiy valyutalar (kod -> ko'rsatiladigan nom)
CURRENCIES = {
    "USD": "🇺🇸 USD",
    "EUR": "🇪🇺 EUR",
    "RUB": "🇷🇺 RUB",
    "GBP": "🇬🇧 GBP",
    "UZS": "🇺🇿 UZS",
    "JPY": "🇯🇵 JPY",
    "CNY": "🇨🇳 CNY",
    "TRY": "🇹🇷 TRY",
    "KZT": "🇰🇿 KZT",
    "AED": "🇦🇪 AED",
}

# Standart holatda "Kurs ko'rish" bo'limida ko'rsatiladigan asosiy valyutalar ro'yxati
DEFAULT_DISPLAY_CURRENCIES = ["USD", "EUR", "RUB", "GBP"]


def main_menu_keyboard(locale: dict, is_admin: bool) -> ReplyKeyboardMarkup:
    """Foydalanuvchi (va agar admin bo'lsa, admin) uchun asosiy menyu."""
    keyboard = [
        [KeyboardButton(text=locale["btn_view_rates"])],
        [KeyboardButton(text=locale["btn_convert"])],
        [KeyboardButton(text=locale["btn_favorites"])],
    ]
    if is_admin:
        keyboard.append(
            [
                KeyboardButton(text=locale["btn_stats"]),
                KeyboardButton(text=locale["btn_broadcast"]),
            ]
        )
    return ReplyKeyboardMarkup(keyboard=keyboard, resize_keyboard=True)


def currency_inline_keyboard(prefix: str) -> InlineKeyboardMarkup:
    """
    Valyuta tanlash uchun inline klaviatura.
    prefix - callback_data ni turli holatlar (manba/maqsad valyuta, sevimlilar) uchun farqlash uchun.
    """
    buttons = []
    row = []
    for i, (code, label) in enumerate(CURRENCIES.items(), start=1):
        row.append(InlineKeyboardButton(text=label, callback_data=f"{prefix}:{code}"))
        if i % 3 == 0:
            buttons.append(row)
            row = []
    if row:
        buttons.append(row)
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def favorites_inline_keyboard(user_favorites: list) -> InlineKeyboardMarkup:
    """
    Sevimli valyutalarni belgilash uchun inline klaviatura.
    Har bir tugma valyuta belgilangan/belgilanmaganini ✅/⬜️ bilan ko'rsatadi.
    """
    buttons = []
    row = []
    for i, (code, label) in enumerate(CURRENCIES.items(), start=1):
        mark = "✅" if code in user_favorites else "⬜️"
        row.append(
            InlineKeyboardButton(text=f"{mark} {label}", callback_data=f"fav:{code}")
        )
        if i % 2 == 0:
            buttons.append(row)
            row = []
    if row:
        buttons.append(row)
    buttons.append(
        [InlineKeyboardButton(text="✅ Saqlash / Готово / Done", callback_data="fav:done")]
    )
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def confirm_keyboard(locale: dict) -> InlineKeyboardMarkup:
    """Reklama yuborishni tasdiqlash/bekor qilish uchun inline klaviatura."""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=locale["confirm_yes"], callback_data="broadcast_confirm"
                ),
                InlineKeyboardButton(
                    text=locale["confirm_no"], callback_data="broadcast_cancel"
                ),
            ]
        ]
    )


def interface_language_keyboard() -> InlineKeyboardMarkup:
    """/language komandasi uchun bot interfeysi tilini tanlash klaviaturasi."""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🇺🇿 O'zbek", callback_data="setlang:uz")],
            [InlineKeyboardButton(text="🇷🇺 Русский", callback_data="setlang:ru")],
            [InlineKeyboardButton(text="🇬🇧 English", callback_data="setlang:en")],
        ]
    )
